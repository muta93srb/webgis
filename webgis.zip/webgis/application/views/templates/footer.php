<link rel="stylesheet" href="<?php echo base_url(); ?>public/css/footer.css">
<footer>
<hr>
<hr>
<p id="f1">&copy; Djordje</p>
</body>
</html>
</footer>
