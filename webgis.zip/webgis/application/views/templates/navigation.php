<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/navigation.css">
        <title>Gde na utakmicu?</title>
        <script src="https://cdn.polyfill.io/v2/polyfill.min.js?features=requestAnimationFrame,Element.prototype.classList,URL"></script>
        <style media="screen">
          main {
            height: 880px;
            background-image: url("<?php echo base_url(); ?>public/img/trava.jpg");
            background-size: cover;
            background-attachment: fixed;
            position: relative;
            bottom: 35px;
          }
        </style>
    </head>
    <body>
        <header>
            <div id="h1">
                <a href="/WebGis">
                    <img src="<?php echo base_url(); ?>public/img/logo.png" alt="Greška!" id="logo">
                </a>
            </div>
            <div id="h2">
                <ul id="menu">
                    <li><a href="/webgis/vidiKartu">Vidi kartu</a></li>
                    <li><a href="/webgis/preuzmiPodatke">Preuzmi podatke</a></li>
                    <li><a href="/webgis">Utakmice</a></li>
                </ul>
            </div>
            <div id="h3"><b>Gde na utakmicu?</b></div>
        </header>
