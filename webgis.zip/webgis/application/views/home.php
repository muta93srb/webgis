        <main>
          <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/ol.css">
          <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/home.css">
          <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
          <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
          <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30=" crossorigin="anonymous"></script>
          <script type="text/javascript" src="<?php echo base_url(); ?>public/js/ol.js"></script>
          <script type="text/javascript" src="<?php echo base_url(); ?>public/js/loadKlubovi.js"></script>
            <div id="m1">
                    <img src="<?php echo base_url(); ?>public/img/zvezda.png" alt="zvezda!" onclick="loadKlub('Crvena Zvezda')">
                    <img src="<?php echo base_url(); ?>public/img/cuka.png" alt="cukaricki!" onclick="loadKlub('Cukaricki')">
                    <img src="<?php echo base_url(); ?>public/img/dinamo.png" alt="dinamo!" onclick="loadKlub('Dinamo')">
                    <img src="<?php echo base_url(); ?>public/img/macva.png" alt="macva!" onclick="loadKlub('Macva')">
                    <img src="<?php echo base_url(); ?>public/img/mladost.png" alt="mladost!" onclick="loadKlub('Mladost')">
                    <img src="<?php echo base_url(); ?>public/img/napredak.png" alt="napredak!" onclick="loadKlub('Napredak')">
                    <img src="<?php echo base_url(); ?>public/img/backa.png" alt="backa!" onclick="loadKlub('Backa')">
                    <img src="<?php echo base_url(); ?>public/img/partizai.png" alt="partizai!" onclick="loadKlub('Partizan')">
                    <img src="<?php echo base_url(); ?>public/img/proleter.png" alt="proleter!" onclick="loadKlub('Proleter')">
                    <img src="<?php echo base_url(); ?>public/img/rad.png" alt="rad!" onclick="loadKlub('Rad')">
                    <img src="<?php echo base_url(); ?>public/img/radnicki.png" alt="radnicki!" onclick="loadKlub('Radnicki')">
                    <img src="<?php echo base_url(); ?>public/img/radnik.png" alt="radnik!" onclick="loadKlub('Radnik')">
                    <img src="<?php echo base_url(); ?>public/img/spartak.png" alt="spartak!" onclick="loadKlub('Spartak')">
                    <img src="<?php echo base_url(); ?>public/img/vojvodina.png" alt="vojvodina!" onclick="loadKlub('Vojvodina')">
                    <img src="<?php echo base_url(); ?>public/img/vozdovac.png" alt="vozdovac!" onclick="loadKlub('Vozdovac')">
                    <img src="<?php echo base_url(); ?>public/img/zemun.png" alt="zemun!" onclick="loadKlub('Zemun')">
            </div>
            <div id="map" class="map"></div>
            <div id="m3"></div>
            <div id="m4">
                <ul id="kolo">
                    <li onclick="loadKolo(1)">1. kolo</li>
                    <li onclick="loadKolo(2)">2. kolo</li>
                    <li onclick="loadKolo(3)">3. kolo</li>
                    <li onclick="loadKolo(4)">4. kolo</li>
                    <li onclick="loadKolo(5)">5. kolo</li>
                    <li onclick="loadKolo(6)">6. kolo</li>
                    <li onclick="loadKolo(7)">7. kolo</li>
                    <li onclick="loadKolo(8)">8. kolo</li>
                    <li onclick="loadKolo(9)">9. kolo</li>
                    <li onclick="loadKolo(10)">10. kolo</li>
                    <li onclick="loadKolo(11)">11. kolo</li>
                    <li onclick="loadKolo(12)">12. kolo</li>
                    <li onclick="loadKolo(13)">13. kolo</li>
                    <li onclick="loadKolo(14)">14. kolo</li>
                    <li onclick="loadKolo(15)">15. kolo</li>
                    <li onclick="loadKolo(16)">16. kolo</li>
                    <li onclick="loadKolo(17)">17. kolo</li>
                    <li onclick="loadKolo(18)">18. kolo</li>
                    <li onclick="loadKolo(19)">19. kolo</li>
                    <li onclick="loadKolo(20)">20. kolo</li>
                    <li onclick="loadKolo(21)">21. kolo</li>
                    <li onclick="loadKolo(22)">22. kolo 16.2.</li>
                    <li onclick="loadKolo(23)">23. kolo 23.2.</li>
                    <li onclick="loadKolo(24)">24. kolo 27.2.</li>
                    <li onclick="loadKolo(25)">25. kolo</li>
                    <li onclick="loadKolo(26)">26. kolo</li>
                    <li onclick="loadKolo(27)">27. kolo</li>
                    <li onclick="loadKolo(28)">28. kolo</li>
                    <li onclick="loadKolo(29)">29. kolo</li>
                    <li onclick="loadKolo(30)">30. kolo</li>
                </ul>
            </div>
            <div id="m5">
              <div class="vidljivost">
              <p  id="v1">Srbija:</p>
              <div id="slider1"></div>
              </div>
              <div class="vidljivost">
              <p id="v2">Putevi</p>
              <div id="slider2"></div>
              </div>
              <div class="vidljivost">
              <p id="v3">Zeleznice</p>
              <div id="slider3"></div>
              </div>
              <div class="vidljivost">
              <p id="v4">Open street map:</p>
              <div id="slider4"></div>
              </div>
              <div class="vidljivost">
              <p id="v5">Svi stadioni:</p>
              <div id="slider5"></div>
              </div>
              <div class="vidljivost">
              <p id="v6">Parking:</p>
              <div id="slider6"></div>
              </div>
              <div class="vidljivost">
              <p id="v7">Stadioni Super lige:</p>
              <div id="slider7"></div>
              </div>
              <div class="vidljivost">
              <p id="v8">Bing maps:</p>
              <div id="slider8"></div>
              </div>
            </div>
            <div id="popup" class="ol-popup">
              <a href="#" id="popup-closer" class="ol-popup-closer"></a>
              <div id="popup-content"></div>
            </div>
        </main>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/mapa.js"></script>
