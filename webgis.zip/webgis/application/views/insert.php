<link rel="stylesheet" href="<?php echo base_url(); ?>public/css/insert.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/ol.css">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30=" crossorigin="anonymous"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/ol.js"></script>
  <main>
    <div id="map" class="map"></div>
    <div id="m1">
    <form class="form-inline" id="crtanje">
      <label>Tip geometrije &nbsp;</label>
      <select id="type">
        <option value="Point">Point</option>
        <option value="LineString">LineString</option>
        <option value="Polygon">Polygon</option>
        <option value="None">None</option>
      </select>
    </form>
    <form id="podaci">
      Naziv: <input type="text" name="name" id="name" value="Gradski stadion Leskovac"><br>
      Klub: <input type="text" name="klub" id="klub" value="Dubocica"><br>
      Grad: <input type="text" name="grad" id="grad" value="Leskovac"><br>
      Longituda: <input type="text" name="lon" id="lon" value="21"><br>
      Latituda: <input type="text" name="lat" id="lat" value="45"><br>
      Pravac prostiranja: <input type="text" name="dir" id="dir" value="0"><br><br>
    </form>
    <button type="button" name="button" id="binsert" onclick="setGeometrija()">Posalji podatke</button>
    </div>
  </main>
  <script type="text/javascript" src="<?php echo base_url(); ?>public/js/insert.js"></script>
</body>
