<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/ol.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/vidiKartu.css">
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/ol.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/js/checksVidiKartu.js"></script>
  <main>
    <div id="map" class="map"></div>
    <div id="m2">
      <form class="form-inline">
      <label>Merenje &nbsp;</label>
      <select id="type">
        <option value="length">Duzina (Linija)</option>
        <option value="area">Povrsina (Poligon)</option>
      </select>
      </form>
      <div id="checks">
        <div class="checks">Stadioni Super lige: <input type="checkbox" id="myCheck1"  onclick="cstadioni()" checked></div>
        <div id="regioni" class="checks">Regioni: <input type="checkbox" id="myCheck2"  onclick="csrbija()" checked></div>
        <div id="putevi" class="checks">Putevi: <input type="checkbox" id="myCheck3"  onclick="cputevi()" checked></div>
        <div id="zeleznice" class="checks">Zeleznice: <input type="checkbox" id="myCheck4"  onclick="czeleznice()" checked></div>
        <div id="parking" class="checks">Parking: <input type="checkbox" id="myCheck5"  onclick="cparking()" checked></div>
        <div id="svistadioni" class="checks">Svi stadioni: <input type="checkbox" id="myCheck6"  onclick="csvistadioni()" checked></div>
        <div class="checks">OSM: <input type="checkbox" id="myCheck7"  onclick="cosm()" checked></div>
      </div>
    </div>
  </main>
  <script type="text/javascript" src="<?php echo base_url(); ?>public/js/mapaWMS.js"></script>
</body>
