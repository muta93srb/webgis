    <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/preuzmiPodatke.css">
    <script type="text/javascript" src="<?php echo base_url(); ?>public/js/preuzmiPodatke.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>public/js/wps.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
        <main>
            <button onclick="loadStadione()" id="b1"><b>Preuzmi lokacije stadiona</b></button>
            <button onclick="zeleznice()" id="b2"><b>Preuzmi trase zeleznickih pruga</b></button>
            <button onclick="putevi()" id="b3"><b>Preuzmi trase puteva</b></button>
            <button onclick="srbija()" id="b4"><b>Preuzmi granice Srbije</b></button>
            <button onclick="parking()" id="b5"><b>Preuzmi podatke o parkinzima</b></button>
            <form action="" id='tip'>
                <input type="radio" name="tip" value="male" id='shapefile'> shapefile<br>
                <input type="radio" name="tip" value="female" id='geojson'> geojson<br>
                <input type="radio" name="tip" value="other" id='kml'> kml
            </form>
            <select id="reg">
              <option value="" selected="selected">Svi</option>
              <option value="1">Borski</option>
              <option value="2">Braniccevski</option>
              <option value="3">Grad Beograd</option>
              <option value="4">Jablanicki</option>
              <option value="5">Juzno-Backi</option>
              <option value="6">Juzno-Banatski</option>
              <option value="7">Kolubarski</option>
              <option value="8">Macvanski</option>
              <option value="9">Moravski</option>
              <option value="10">Nisavski</option>
              <option value="11">Pcinjski</option>
              <option value="12">Pirotiski</option>
              <option value="13">Podunavski</option>
              <option value="14">Pomoravski</option>
              <option value="15">Rasinski</option>
              <option value="16">Raski</option>
              <option value="17">Severno-Backi</option>
              <option value="18">Severno-Banatski</option>
              <option value="19">Srednje-Banatski</option>
              <option value="20">Sremski</option>
              <option value="21">Sumadijski</option>
              <option value="22">Toplicki</option>
              <option value="23">Zajecarski</option>
              <option value="24">Zapadno-Backi</option>
              <option value="25">Zlatiborski</option>
              <option value="26">Djakovicki</option>
              <option value="27">Gnjilane</option>
              <option value="28">Kosovska Mitrovica</option>
              <option value="29">Pecki</option>
              <option value="30">Pristina</option>
              <option value="31">Prizren</option>
              <option value="32">Urosevac</option>
            </select>
            <p id="reglab">Naziv regiona u kom zelite podatke o stadionima: <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(dostupno samo u JSON formatu) </p>
        </main>
</body>
