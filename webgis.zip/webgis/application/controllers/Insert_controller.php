<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insert_controller extends CI_Controller {
  public function insertStadion() {
    $name = $this->input->post("name");
    $klub = $this->input->post("klub");
    $grad = $this->input->post("grad");
    $lon = $this->input->post("lon");
    $lat = $this->input->post("lat");
    $dir = $this->input->post("dir");
    $x = $this->input->post("x");
    $y = $this->input->post("y");
    $upit1 = "SELECT MAX(id) AS maks FROM stadioni";
    $id = $this->db->query($upit1)->result();
    $id = $id[0]->maks + 1;
    $geom = $this->db->query("SELECT ST_MPointFromText('MULTIPOINT(".$x." ".$y." 0)', 4326)")->result();
    $geom = $geom[0]->st_mpointfromtext;
    $upit2 = "INSERT INTO stadioni
              VALUES($id, '$geom', '{$name}', '{$klub}', '{$grad}', $lon, $lat, $dir);";
    $this->db->query($upit2);
  }
}
?>
