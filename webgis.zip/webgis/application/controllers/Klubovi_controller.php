<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Klubovi_controller extends CI_Controller {
  public function setKolo() {
    $kolo = $this->input->post("kolo");
    if (!isset($_SESSION['gklub'])) {
      $_SESSION['gkolo'] = $kolo;
    } else {
      $_SESSION['gkolo'] = $kolo;
      $klub = $_SESSION['gklub'];
      $upit = "SELECT kolo, domacin, gost, grad, name, lon, lat FROM raspored , stadioni
      WHERE domacin = klub AND kolo = {$kolo} AND ( klub = '{$klub}' OR gost = '{$klub}') ";
      $stadion = $this->db->query($upit)->result();
      echo json_encode($stadion);
    }
  }
  public function setKlub() {
    $klub = $this->input->post("klub");
    if (!isset($_SESSION['gkolo'])) {
      $_SESSION['gklub'] = $klub;
    } else {
      $_SESSION['gklub'] = $klub;
      $kolo = $_SESSION['gkolo'];
      $upit = "SELECT kolo, domacin, gost, grad, name, lon, lat FROM raspored , stadioni
      WHERE domacin = klub AND kolo = {$kolo} AND ( klub = '{$klub}'  OR gost = '{$klub}') ";
      $stadion = $this->db->query($upit)->result();
      echo json_encode($stadion);
    }
  }
}
?>
