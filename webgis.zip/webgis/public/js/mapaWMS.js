var source = new ol.source.Vector();

var vector = new ol.layer.Vector({
  source: source,
  style: new ol.style.Style({
    fill: new ol.style.Fill({
      color: 'rgba(255, 255, 255, 0.2)'
    }),
    stroke: new ol.style.Stroke({
      color: '#32c8ff',
      width: 2
    }),
    image: new ol.style.Circle({
      radius: 7,
      fill: new ol.style.Fill({
        color: '#32c8ff'
      })
    })
  })
});
var sketch;
var helpTooltipElement;
var helpTooltip;
var measureTooltipElement;
var measureTooltip;
var continuePolygonMsg = 'Levi klik za nastavak crtanja poligona';
var continueLineMsg = 'Levi klik za nastavak crtanja linije';
var pointerMoveHandler = function(evt) {
  if (evt.dragging) {
    return;
  }
  /** @type {string} */
  var helpMsg = 'Pretisnite levi klik za pocetak crtanja';
    if (sketch) {
    var geom = (sketch.getGeometry());
    if (geom instanceof ol.geom.Polygon) {
      helpMsg = continuePolygonMsg;
    } else if (geom instanceof ol.geom.LineString) {
      helpMsg = continueLineMsg;
    }
  }
  helpTooltipElement.innerHTML = helpMsg;
  helpTooltip.setPosition(evt.coordinate);
  helpTooltipElement.classList.remove('hidden');
};
var osm = new ol.layer.Tile({
source: new ol.source.OSM()
})
var srbija = new ol.layer.Image({
  title: 'srbija',
  source: new ol.source.ImageWMS({
    url: 'http://localhost:8080/geoserver/wms',
    params: {'LAYERS': 'WebGis:srbija'},
    serverType: 'geoserver',
    crossOrigin: 'anonymous'
  }),
  minResolution: 200,
  maxResolution: 2000
})
var putevi = new ol.layer.Image({
  title: 'putevi',
  source: new ol.source.ImageWMS({
    url: 'http://localhost:8080/geoserver/wms',
    params: {'LAYERS': 'WebGis:putevi'},
    serverType: 'geoserver',
    crossOrigin: 'anonymous'
  })
})
var zeleznice = new ol.layer.Image({
    title: 'zeleznice',
    source: new ol.source.ImageWMS({
      url: 'http://localhost:8080/geoserver/wms',
      params: {'LAYERS': 'WebGis:zeleznice'},
      serverType: 'geoserver',
      crossOrigin: 'anonymous'
    })
  })
var parking = new ol.layer.Image({
    title: 'parking',
    source: new ol.source.ImageWMS({
      url: 'http://localhost:8080/geoserver/wms',
      params: {'LAYERS': 'WebGis:parking'},
      serverType: 'geoserver',
      crossOrigin: 'anonymous'
    })
  })
var svistadioni = new ol.layer.Image({
    title: 'svistadioni',
    source: new ol.source.ImageWMS({
      url: 'http://localhost:8080/geoserver/wms',
      params: {'LAYERS': 'WebGis:svistadioni'},
      serverType: 'geoserver',
      crossOrigin: 'anonymous'
    })
  })
var stadioni = new ol.layer.Image({
  title: 'stadioni',
  source: new ol.source.ImageWMS({
    url: 'http://localhost:8080/geoserver/wms',
    params: {'LAYERS': 'WebGis:stadioni'},
    serverType: 'geoserver',
    crossOrigin: 'anonymous'
  })
})
var stadioni2 = new ol.layer.Image({
    title: 'stadioni2',
    source: new ol.source.ImageWMS({
      url: 'http://localhost:8080/geoserver/wms',
      params: {'LAYERS': 'WebGis:stadioni2'},
      serverType: 'geoserver',
      crossOrigin: 'anonymous'
    })
  })

var map = new ol.Map({
  layers: [
    osm,
    srbija,
    putevi,
    zeleznice,
    parking,
    svistadioni,
    stadioni,
    vector,
    stadioni2
    ],
  target: 'map',
  view: new ol.View({
    center: ol.proj.fromLonLat([21, 44]),
    zoom: 7
  })
});
var zoomslider = new ol.control.ZoomSlider();
map.addControl(zoomslider);
map.on('pointermove', pointerMoveHandler);
map.getViewport().addEventListener('mouseout', function() {
  helpTooltipElement.classList.add('hidden');
});
var typeSelect = document.getElementById('type');
var draw; // global so we can remove it later
var formatLength = function(line) {
  var length = ol.sphere.getLength(line);
  var output;
    if (length > 100) {
      output = (Math.round(length / 1000 * 100) / 100) +
          ' ' + 'km';
    } else {
      output = (Math.round(length * 100) / 100) +
          ' ' + 'm';
    }
    return output;
  };
var formatArea = function(polygon) {
  var area = ol.sphere.getArea(polygon);
  var output;
  if (area > 10000) {
    output = (Math.round(area / 1000000 * 100) / 100) +
        ' ' + 'km<sup>2</sup>';
  } else {
    output = (Math.round(area * 100) / 100) +
        ' ' + 'm<sup>2</sup>';
  }
  return output;
};
function addInteraction() {
  var type = (typeSelect.value == 'area' ? 'Polygon' : 'LineString');
  draw = new ol.interaction.Draw({
    source: source,
    type: type,
    style: new ol.style.Style({
      fill: new ol.style.Fill({
        color: 'rgba(255, 255, 255, 0.2)'
      }),
      stroke: new ol.style.Stroke({
        color: 'rgba(0, 0, 0, 0.5)',
        lineDash: [10, 10],
        width: 2
      }),
      image: new ol.style.Circle({
        radius: 5,
        stroke: new ol.style.Stroke({
          color: 'rgba(0, 0, 0, 0.7)'
        }),
        fill: new ol.style.Fill({
          color: 'rgba(255, 255, 255, 0.2)'
        })
      })
    })
  });
  map.addInteraction(draw);
  createMeasureTooltip();
  createHelpTooltip();
  var listener;
  draw.on('drawstart',
  function(evt) {
    sketch = evt.feature;
      var tooltipCoord = evt.coordinate;
      listener = sketch.getGeometry().on('change', function(evt) {
      var geom = evt.target;
    var output;
      if (geom instanceof ol.geom.Polygon) {
        output = formatArea(geom);
        tooltipCoord = geom.getInteriorPoint().getCoordinates();
      } else if (geom instanceof ol.geom.LineString) {
        output = formatLength(geom);
        tooltipCoord = geom.getLastCoordinate();
      }
      measureTooltipElement.innerHTML = output;
      measureTooltip.setPosition(tooltipCoord);
    });
  }, this);
  draw.on('drawend',
  function() {
    measureTooltipElement.className = 'tooltip tooltip-static';
    measureTooltip.setOffset([0, -7]);
    sketch = null;
    measureTooltipElement = null;
    createMeasureTooltip();
    ol.Observable.unByKey(listener);
  }, this);
}
function createHelpTooltip() {
  if (helpTooltipElement) {
    helpTooltipElement.parentNode.removeChild(helpTooltipElement);
  }
  helpTooltipElement = document.createElement('div');
  helpTooltipElement.className = 'tooltip hidden';
    helpTooltip = new ol.Overlay({
      element: helpTooltipElement,
      offset: [15, 0],
      positioning: 'center-left'
    });
    map.addOverlay(helpTooltip);
  }
  function createMeasureTooltip() {
    if (measureTooltipElement) {
        measureTooltipElement.parentNode.removeChild(measureTooltipElement);
      }
    measureTooltipElement = document.createElement('div');
    measureTooltipElement.className = 'tooltip tooltip-measure';
    measureTooltip = new ol.Overlay({
      element: measureTooltipElement,
      offset: [0, -15],
        positioning: 'bottom-center'
    });
    map.addOverlay(measureTooltip);
  }
  typeSelect.onchange = function() {
    map.removeInteraction(draw);
    addInteraction();
  };
  addInteraction();
