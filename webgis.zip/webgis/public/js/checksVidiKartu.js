  function cstadioni() {
    var checkBox = document.getElementById("myCheck1");
    if (checkBox.checked == true){
      stadioni.setVisible(true);
      stadioni2.setVisible(true);
    } else {
      stadioni.setVisible(false);
      stadioni2.setVisible(false);
    }
  }
  function csrbija() {
    var checkBox = document.getElementById("myCheck2");
    if (checkBox.checked == true){
      srbija.setVisible(true);
    } else {
      srbija.setVisible(false);
    }
  }
  function cputevi() {
    var checkBox = document.getElementById("myCheck3");
    if (checkBox.checked == true){
      putevi.setVisible(true);
    } else {
      putevi.setVisible(false);
    }
  }
  function czeleznice() {
    var checkBox = document.getElementById("myCheck4");
    if (checkBox.checked == true){
      zeleznice.setVisible(true);
    } else {
      zeleznice.setVisible(false);
    }
  }
  function cparking() {
    var checkBox = document.getElementById("myCheck5");
    if (checkBox.checked == true){
      parking.setVisible(true);
    } else {
      parking.setVisible(false);
    }
  }
  function csvistadioni() {
    var checkBox = document.getElementById("myCheck6");
    if (checkBox.checked == true){
      svistadioni.setVisible(true);
    } else {
      svistadioni.setVisible(false);
    }
  }
  function cosm() {
    var checkBox = document.getElementById("myCheck7");
    if (checkBox.checked == true){
      osm.setVisible(true);
    } else {
      osm.setVisible(false);
    }
  }
