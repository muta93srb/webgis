
      var raster = new ol.layer.Tile({
        source: new ol.source.OSM()
      });

      var source = new ol.source.Vector();

      var vector = new ol.layer.Vector({
        source: source
      });

      var map = new ol.Map({
        layers: [raster, vector],
        target: 'map',
        view: new ol.View({
          center: ol.proj.fromLonLat([21, 44]),
          zoom: 7
        })
      });

      var typeSelect = document.getElementById('type');

      var draw; // global so we can remove it later
      function addInteraction() {
        var value = typeSelect.value;
        if (value !== 'None') {
          draw = new ol.interaction.Draw({
            source: source,
            type: typeSelect.value
          });
          map.addInteraction(draw);
        }
      }

      typeSelect.onchange = function() {
        map.removeInteraction(draw);
        addInteraction();
      };

      addInteraction();

      var x,y,lon,lat;

      map.on("singleclick", function(evt){
        var coord = ol.proj.transform(evt.coordinate, 'EPSG:3857', 'EPSG:4326');
        x = coord[0];
        y = coord[1];
        lon = x;
        lat = y;
      });

      function setGeometrija() {
        var name = document.getElementById('name').value;
        var klub = document.getElementById('klub').value;
        var grad = document.getElementById('grad').value;
        var dir = document.getElementById('dir').value;
        $.ajax({
          type:"POST",
          url:"insertStadion",
          data: {name:name, klub:klub, grad:grad, lon:lon, lat:lat, dir:dir, x:x, y:y},
          success: function(data) {
            alert(data);
          }
        })
      }
