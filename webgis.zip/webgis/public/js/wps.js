function downloadObjectAsJson(exportObj, exportName){
  var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportObj));
  var downloadAnchorNode = document.createElement('a');
  downloadAnchorNode.setAttribute("href",     dataStr);
  downloadAnchorNode.setAttribute("download", exportName + ".json");
  document.body.appendChild(downloadAnchorNode); // required for firefox
  downloadAnchorNode.click();
  downloadAnchorNode.remove();
}

function loadStadione(){
  var $reg = document.getElementById("reg");
  var $region = $reg.options[$reg.selectedIndex].value;
  console.log($reg);
  console.log($region);
  if ($region != "") {
    $region = "&amp;featureID=" + $region
  };
  $.ajax({
    type: "POST",
    url: "http://localhost:8080/geoserver/wps",
    data: '<?xml version="1.0" encoding="UTF-8"?><wps:Execute version="1.0.0" service="WPS" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.opengis.net/wps/1.0.0" xmlns:wfs="http://www.opengis.net/wfs" xmlns:wps="http://www.opengis.net/wps/1.0.0" xmlns:ows="http://www.opengis.net/ows/1.1" xmlns:gml="http://www.opengis.net/gml" xmlns:ogc="http://www.opengis.net/ogc" xmlns:wcs="http://www.opengis.net/wcs/1.1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="http://www.opengis.net/wps/1.0.0 http://schemas.opengis.net/wps/1.0.0/wpsAll.xsd">  <ows:Identifier>gs:IntersectionFeatureCollection</ows:Identifier>  <wps:DataInputs>    <wps:Input>      <ows:Identifier>first feature collection</ows:Identifier>      <wps:Reference mimeType="application/json" xlink:href="http://localhost:8080/geoserver/WebGis/ows?service=WFS&amp;version=1.0.0&amp;request=GetFeature&amp;typeName=WebGis%3Asrbija' + $region + '&amp;outputFormat=application%2Fjson" method="GET"/>    </wps:Input>    <wps:Input>      <ows:Identifier>second feature collection</ows:Identifier>      <wps:Reference mimeType="application/json" xlink:href="http://localhost:8080/geoserver/WebGis/ows?service=WFS&amp;version=1.0.0&amp;request=GetFeature&amp;typeName=WebGis%3Astadioni&amp;outputFormat=application%2Fjson" method="GET"/>    </wps:Input>    <wps:Input>      <ows:Identifier>intersectionMode</ows:Identifier>      <wps:Data>        <wps:LiteralData>SECOND</wps:LiteralData>      </wps:Data>    </wps:Input>  </wps:DataInputs>  <wps:ResponseForm>    <wps:RawDataOutput mimeType="application/json">      <ows:Identifier>result</ows:Identifier>    </wps:RawDataOutput>  </wps:ResponseForm></wps:Execute>',
    dataType: 'json',
    jsonpCallback: 'getJson',
    contentType: 'application/json',
    success: function(result){
      downloadObjectAsJson(result, 'stadioni');
    }
  });
};
