var container = document.getElementById('popup');
var content = document.getElementById('popup-content');
var closer = document.getElementById('popup-closer');

var overlay = new ol.Overlay({
  element: container,
  autoPan: true,
  autoPanAnimation: {
    duration: 250
  }
});

closer.onclick = function() {
  overlay.setPosition(undefined);
  closer.blur();
  return false;
};

var map = new ol.Map({
  target: 'map',
  layers: [ ],
  overlays: [overlay],
  loadTilesWhileAnimating: true,
  view: new ol.View({
    center: ol.proj.fromLonLat([21, 44]),
    zoom: 7,
  }),
  projection: '3857'
});
var zoomslider = new ol.control.ZoomSlider();
map.addControl(zoomslider);
var osm = new ol.layer.Tile({
  source: new ol.source.OSM()
})
var srbija = new ol.layer.Vector({
  title: 'layer_name',
  source: new ol.source.Vector({
    url: 'http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Asrbija&outputFormat=application%2Fjson',
    format: new ol.format.GeoJSON(),
    params: {'LAYERS': 'WebGis:srbija'},
    serverType: 'geoserver'
  }),
  transparent: true,
  minResolution: 200,
  maxResolution: 2000,
  style: new ol.style.Style({
    fill: new ol.style.Fill({
      color: 'rgba(16,176,240, 0.2)' //13aff0
    }),
    stroke: new ol.style.Stroke({
      color: 'rgba(1,1,240, 0.5)',
      width: 1
    })
  })
});
var zeleznice = new ol.layer.Vector({
  title: 'layer_name',
  source: new ol.source.Vector({
   url: 'http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Azeleznice&outputFormat=application%2Fjson',
   format: new ol.format.GeoJSON(),
   params: {'LAYERS': 'WebGis:zeleznice'},
   serverType: 'geoserver'
  }),
  style: new ol.style.Style({
    stroke: new ol.style.Stroke({
      width: 2, color: 'rgba(181, 16, 13, 1)'
    })
  })
});
var putevi = new ol.layer.Vector({
  title: 'layer_name',
  source: new ol.source.Vector({
   url: 'http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Aputevi&outputFormat=application%2Fjson',
   format: new ol.format.GeoJSON(),
   params: {'LAYERS': 'WebGis:putevi'},
   serverType: 'geoserver'
  }),
  style: new ol.style.Style({
    stroke: new ol.style.Stroke({
      width: 1, color: 'rgba(173, 66, 244, 1)'
    })
  })
});
var parking = new ol.layer.Vector({
  title: 'layer_name',
  source: new ol.source.Vector({
   url: 'http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Aparking&outputFormat=application%2Fjson',
   format: new ol.format.GeoJSON(),
   params: {'LAYERS': 'WebGis:parking'},
   serverType: 'geoserver'
  }),
  maxResolution: 50,
    style: new ol.style.Style({
      fill: new ol.style.Fill({
        color: 'rgba(1,1,225, 0.5)'
      }),
    stroke: new ol.style.Stroke({
      color: '#000000',
        width: 0
    })
  }),
  opacity: 0
});
var svistadioni = new ol.layer.Vector({
  title: 'layer_name',
  source: new ol.source.Vector({
   url: 'http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Asvistadioni&outputFormat=application%2Fjson',
   format: new ol.format.GeoJSON(),
   params: {'LAYERS': 'WebGis:svistadioni'},
   serverType: 'geoserver'
}),
  maxResolution: 50,
    style: new ol.style.Style({
      fill: new ol.style.Fill({
        color: 'rgba(1,255,1, 0.5)'
    })
  }),
  opacity: 0
});
var stadioni = new ol.layer.Vector({
  title: 'layer_name',
  source: new ol.source.Vector({
   url: 'http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Astadioni&outputFormat=application%2Fjson',
   format: new ol.format.GeoJSON(),
   params: {'LAYERS': 'WebGis:stadioni'},
   serverType: 'geoserver'
  }),
  style: (function() {
    var style = new ol.style.Style({
      image: new ol.style.Icon({
        scale: 0.05,
        src: 'public/img/stadion.svg',
        rotate: 1
      }),
    text: new ol.style.Text({
    text: 'Muta',
    scale: 1.3,
    offsetY: 20,
    fill: new ol.style.Fill({
      color: '#135ff0'
    }),
    stroke: new ol.style.Stroke({
      color: '#FFFFFF',
    width: 5
    })
  })
});
var styles = [style];
return function(feature, resolution) {
  style.getText().setText(feature.get("name"));
  style.getImage().setRotation(feature.get("dir"));
  return styles;
};
})()
});
var bing = new ol.layer.Tile({
  source: new ol.source.BingMaps({
    key: 'Ak5QapMwNLmex8B2yriujDpi3TG0QKOlkX6uKEVL7-zbQljkpxZXY1uWMtZxcNql',
    imagerySet: 'Aerial',
  })
});
var bing2 = new ol.layer.Tile({
  source: new ol.source.BingMaps({
    key: 'Ak5QapMwNLmex8B2yriujDpi3TG0QKOlkX6uKEVL7-zbQljkpxZXY1uWMtZxcNql',
    imagerySet: 'AerialWithLabels'
  })
});
$( function() {
  $( "#slider1" ).slider({
    value: 100,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      srbija.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider2" ).slider({
    value: 100,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      putevi.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider3" ).slider({
    value: 100,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      zeleznice.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider4" ).slider({
    value: 100,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      osm.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider5" ).slider({
    value: 0,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      svistadioni.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider6" ).slider({
    value: 0,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      parking.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider7" ).slider({
    value: 100,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      stadioni.setOpacity(ui.value / 100);
    }
  });
});
$( function() {
  $( "#slider8" ).slider({
    value: 0,
    min: 0,
    max: 100,
    step: 1,
    slide: function( event, ui ) {
      bing.setOpacity(ui.value / 100);
      bing2.setOpacity(ui.value / 100);
    }
  });
});

map.addLayer(osm);
map.addLayer(bing);
map.addLayer(bing2);
map.addLayer(srbija);
map.addLayer(zeleznice);
map.addLayer(putevi);
map.addLayer(parking);
map.addLayer(svistadioni);
map.addLayer(stadioni);
parking.setOpacity(0);
svistadioni.setOpacity(0);
bing.setOpacity(0);
bing2.setOpacity(0);

map.on('singleclick', function(evt) {
  var coordinate = evt.coordinate;
  var feature = map.forEachFeatureAtPixel(evt.pixel,
    function(feature, layer) {
      console.log(layer);
      if (layer == stadioni){
        content.innerHTML = 'Naziv stadiona: ' + feature.values_.name + '; <br>Naziv kluba: ' + feature.values_.klub + '; <br>Naziv grada: ' + feature.values_.grad + ';';
      } else if (layer == putevi) {
        content.innerHTML = 'Naziv puta: ' + feature.values_.namesr + '; <br>Maksimalna brzina: ' + feature.values_.maxspeed + '; <br>Jednosmerna: ' + feature.values_.oneway + ';';
      } else if (layer == zeleznice) {
        content.innerHTML = 'Stanje: ' + feature.values_.railway + '; <br>Upotreba: ' + feature.values_.usage + '; <br>Most: ' + feature.values_.bridge + ';';
      } else if (layer == parking) {
        content.innerHTML = 'Kapacitet: ' + feature.values_.capacity + '; <br>Placanje: ' + feature.values_.fee + '; <br>Povrsina: ' + feature.values_.surface + ';';
      }  else if (layer == srbija) {
        content.innerHTML = 'Naziv okruga: ' + feature.values_.name_1 + ';';
      }
  });
  overlay.setPosition(coordinate);
});
