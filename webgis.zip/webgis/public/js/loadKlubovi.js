function loadKolo(kolo) {
  $.ajax({
    type:"POST",
    url:"setKolo",
    data: {kolo:kolo},
    success: function(data) {
      kolo=JSON.parse(data);
      console.log(kolo);
      var $lon1 = parseFloat(kolo[0].lon);
      var $lat1 = parseFloat(kolo[0].lat);
      var $pogled = ol.proj.fromLonLat([$lon1, $lat1]);
      map.getView().animate({
        center: $pogled,
        duration: 2000,
        zoom: 16
      });
      var t = 'Domacin FK '+ kolo[0].domacin + ' docekuje FK ' + kolo[0].gost + ' u utakmici ' + kolo[0].kolo + '. kola na stadionu "' + kolo[0].name + '", cena ulaznice se krece od 200 do 800 dinara, i mogu se kupiti na sajtu: <a href="https://www.iticket.rs">iTicket</a>'
      $('#m3').html(t);
    }
  })
}
function loadKlub(klub) {
  $.ajax({
    type:"POST",
    url:"setKlub",
    data: {klub:klub},
    success: function(data) {
      klub=JSON.parse(data);
      console.log(klub);
      var $lon2 = parseFloat(klub[0].lon);
      var $lat2 = parseFloat(klub[0].lat);
      var $pogled = ol.proj.fromLonLat([$lon2, $lat2]);
      map.getView().animate({
        center: $pogled,
        duration: 2000,
        zoom: 16
      });
      $('#m3').html('Domacin FK '+ klub[0].domacin + ' docekuje FK ' + klub[0].gost + ' u utakmici ' + klub[0].kolo + '. kola na stadionu "' + klub[0].name + '", cena ulaznice se krece od 200 do 800 dinara, i mogu se kupiti na sajtu: <a href="https://www.iticket.rs">iTicket</a>');
    }
  })
}
