function tipPodataka() {
    var t = "";
    if (document.getElementById("shapefile").checked === true) {
        t = "SHAPE-ZIP";
    } else if (document.getElementById("geojson").checked === true) {
        t = "application%2Fjson";
    } else if (document.getElementById("kml").checked === true) {
        t = "application%2Fvnd.google-earth.kml%2Bxml";
    } else {
        document.getElementById("h3").innerHTML = "Izaberite format u kom zelite podatke";
        document.getElementById("h3").style.fontSize = "50px";
    }
    return t;
}

function stadioni() {
    var a = "http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Astadioni&outputFormat=";
    var b = "";
    b = tipPodataka();
    if (b === "") {
        exit;
    } else {
        var c = a + b;
        window.open(c);
    }
}

function putevi() {
    var a = "http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Aputevi&outputFormat=";
    var b = "";
    b = tipPodataka();
    if (b === "") {
        exit;
    } else {
        var c = a + b;
        window.open(c);
    }
}

function zeleznice() {
    var a = "http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Azeleznice&outputFormat=";
    var b = "";
    b = tipPodataka();
    if (b === "") {
        exit;
    } else {
        var c = a + b;
        window.open(c);
    }
}

function srbija() {
    var a = "http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Asrbija&outputFormat=";
    var b = "";
    b = tipPodataka();
    if (b === "") {
        exit;
    } else {
        var c = a + b;
        window.open(c);
    }
}

function parking() {
    var a = "http://localhost:8080/geoserver/WebGis/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=WebGis%3Aparking&outputFormat=";
    var b = "";
    b = tipPodataka();
    if (b === "") {
        exit;
    } else {
        var c = a + b;
        window.open(c);
    }
}
